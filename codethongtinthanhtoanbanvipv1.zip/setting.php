<?
$anhchinh = 'https://i.imgur.com/wOy4VJw.jpg'; // avatar của hình
/* ------------------------------------- */
$gioitinh = 'Nam'; // giới tính
/* ------------------------------------- */
$linkweb = 'https://chauthebao.com'; // link website
/* ------------------------------------- */
$hovaten = 'Châu Thế Bảo'; // ghi tên bằng in hoa hay gì cũng đc
/* ------------------------------------- */
$tieusu = '<br>tui đz<br>'; // ghi tên bằng in hoa hay gì cũng đc
/* ------------------------------------- */
$bietdanh = 'Châu Thế Bảo'; // biệt danh
/* ------------------------------------- */
$ngaysinh = '4-2-2010'; //
/* ------------------------------------- */
$mbbank ='0123456789'; //nhập tk mbbank
$momo ='0123456789'; //nhập tk momo
$vietcombank ='SCB : 0123456789'; //nhập ngan hàng khác
$nganhangkhac ='SCB : 0123456789'; //nhập ngan hàng khác
/* ------------------------------------- */
$linkfb ='méo có'; // nhập link fb vào
/* ------------------------------------- */
$linkzalo ='méo có'; // nhập link zalo vào
/* ------------------------------------- */
$sothich ='Làm code thuê'; //sở thích
$tencopyright ='Châu Thế Bảo'; //tên ở dòng coppyright
?>